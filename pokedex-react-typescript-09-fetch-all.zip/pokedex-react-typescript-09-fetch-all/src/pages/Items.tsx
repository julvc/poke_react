const Items = () => {
  return <div>ITEMS</div>;
};

export default Items;
