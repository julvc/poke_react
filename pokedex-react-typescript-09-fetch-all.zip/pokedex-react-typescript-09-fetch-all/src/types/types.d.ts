export type Pokemon = {
  name: string;
  id: string;
  imgSrc: string;
};
